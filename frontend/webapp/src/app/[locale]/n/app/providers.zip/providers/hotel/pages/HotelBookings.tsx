"use client"

import { useState } from 'react';
import { DashboardLayout } from '../../../design-system/dashboard-components';
import { 
  LayoutDashboard, Calendar, Hotel, DollarSign, Image, Star, BarChart3, CreditCard, MessageSquare, Settings, Bed, Sparkles,
  Search, Filter, MoreVertical, X, Users
} from 'lucide-react';

export default function HotelBookings() {
  const [selectedBooking, setSelectedBooking] = useState<any>(null);

  const navigation = [
    { label: 'Dashboard', icon: <LayoutDashboard size={20} />, path: '/provider/hotel/dashboard' },
    { label: 'Bookings', icon: <Calendar size={20} />, path: '/provider/hotel/bookings', badge: 12 },
    { label: 'Room Inventory', icon: <Bed size={20} />, path: '/provider/hotel/rooms' },
    { label: 'Room Categories', icon: <Hotel size={20} />, path: '/provider/hotel/categories' },
    { label: 'Amenities', icon: <Sparkles size={20} />, path: '/provider/hotel/amenities' },
    { label: 'Pricing', icon: <DollarSign size={20} />, path: '/provider/hotel/pricing' },
    { label: 'Availability', icon: <Calendar size={20} />, path: '/provider/hotel/availability' },
    { label: 'Gallery', icon: <Image size={20} />, path: '/provider/hotel/gallery' },
    { label: 'Reviews', icon: <Star size={20} />, path: '/provider/hotel/reviews' },
    { label: 'Analytics', icon: <BarChart3 size={20} />, path: '/provider/hotel/analytics' },
    { label: 'Billing', icon: <CreditCard size={20} />, path: '/provider/hotel/billing' },
    { label: 'Support', icon: <MessageSquare size={20} />, path: '/provider/hotel/support' },
    { label: 'Settings', icon: <Settings size={20} />, path: '/provider/hotel/settings' },
  ];

  const bookings = [
    { id: 'BK-8472', guest: 'Robert Johnson', room: 'Deluxe Suite', checkin: '2026-03-12', checkout: '2026-03-15', guests: 2, status: 'confirmed', payment: 'paid', source: 'Direct' },
    { id: 'BK-8473', guest: 'Maria Garcia', room: 'Executive Room', checkin: '2026-03-13', checkout: '2026-03-17', guests: 1, status: 'confirmed', payment: 'paid', source: 'Booking.com' },
    { id: 'BK-8474', guest: 'David Chen', room: 'Family Suite', checkin: '2026-03-14', checkout: '2026-03-18', guests: 4, status: 'pending', payment: 'pending', source: 'Expedia' },
  ];

  return (
    <DashboardLayout 
      navigation={navigation} 
      headerTitle="Reservation Management"
      userRole="provider"
      userName="Amanda Rodriguez"
      providerName="Grand Palace Hotel"
    >
      <div className="grid grid-cols-4 gap-6 mb-6">
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <div className="text-sm font-medium text-gray-600 mb-2">Total Bookings</div>
          <div className="text-2xl font-bold text-gray-900">12</div>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <div className="text-sm font-medium text-gray-600 mb-2">Confirmed</div>
          <div className="text-2xl font-bold text-green-900">10</div>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <div className="text-sm font-medium text-gray-600 mb-2">Check-ins Today</div>
          <div className="text-2xl font-bold text-blue-900">6</div>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <div className="text-sm font-medium text-gray-600 mb-2">Revenue</div>
          <div className="text-2xl font-bold text-indigo-900">$18,450</div>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-4 mb-6">
        <div className="flex items-center gap-4">
          <div className="flex-1 relative">
            <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search by guest name or booking ID..."
              className="w-full h-10 pl-10 pr-4 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#083f30]"
            />
          </div>
          <div className="flex items-center gap-2">
            <Filter size={18} className="text-gray-500" />
            <select className="h-10 px-3 bg-gray-50 border border-gray-200 rounded-lg text-sm">
              <option>All Status</option>
              <option>Confirmed</option>
              <option>Pending</option>
            </select>
            <input type="date" defaultValue="2026-03-10" className="h-10 px-3 bg-gray-50 border border-gray-200 rounded-lg text-sm" />
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50 border-b border-gray-200">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Booking ID</th>
              <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Guest Name</th>
              <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Room Category</th>
              <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Check-in</th>
              <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Check-out</th>
              <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Guests</th>
              <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Status</th>
              <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Source</th>
              <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {bookings.map(booking => (
              <tr key={booking.id} className="hover:bg-gray-50">
                <td className="px-6 py-4 text-sm font-medium text-gray-900">{booking.id}</td>
                <td className="px-6 py-4 text-sm text-gray-900">{booking.guest}</td>
                <td className="px-6 py-4 text-sm text-gray-900">{booking.room}</td>
                <td className="px-6 py-4 text-sm text-gray-900">{booking.checkin}</td>
                <td className="px-6 py-4 text-sm text-gray-900">{booking.checkout}</td>
                <td className="px-6 py-4">
                  <div className="flex items-center gap-1 text-sm">
                    <Users size={14} />
                    {booking.guests}
                  </div>
                </td>
                <td className="px-6 py-4">
                  <span className={`px-2.5 py-1 rounded-full text-xs font-semibold ${
                    booking.status === 'confirmed' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'
                  }`}>
                    {booking.status.toUpperCase()}
                  </span>
                </td>
                <td className="px-6 py-4 text-sm text-gray-900">{booking.source}</td>
                <td className="px-6 py-4">
                  <button onClick={() => setSelectedBooking(booking)} className="p-2 hover:bg-gray-100 rounded-lg">
                    <MoreVertical size={18} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {selectedBooking && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={() => setSelectedBooking(null)}>
          <div className="bg-white rounded-2xl p-6 w-[500px]" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-6">
              <h3 className="font-semibold text-gray-900 text-lg">Booking Details</h3>
              <button onClick={() => setSelectedBooking(null)} className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-gray-100">
                <X size={20} />
              </button>
            </div>

            <div className="space-y-4">
              <div className="flex justify-between">
                <span className="text-gray-600">Booking ID</span>
                <span className="font-medium">{selectedBooking.id}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Guest Name</span>
                <span className="font-medium">{selectedBooking.guest}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Room Category</span>
                <span className="font-medium">{selectedBooking.room}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Check-in</span>
                <span className="font-medium">{selectedBooking.checkin}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Check-out</span>
                <span className="font-medium">{selectedBooking.checkout}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Number of Guests</span>
                <span className="font-medium">{selectedBooking.guests}</span>
              </div>

              <div className="flex gap-3 pt-4 border-t">
                <button className="flex-1 h-10 bg-[#083f30] text-white rounded-lg font-medium">Confirm</button>
                <button className="flex-1 h-10 border border-gray-300 text-gray-700 rounded-lg font-medium">Modify</button>
                <button className="flex-1 h-10 border border-red-300 text-red-700 rounded-lg font-medium">Cancel</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </DashboardLayout>
  );
}
